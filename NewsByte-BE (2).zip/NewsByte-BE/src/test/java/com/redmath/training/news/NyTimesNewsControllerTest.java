package com.redmath.training.news;


import com.fasterxml.jackson.databind.ObjectMapper;
import org.hamcrest.Matchers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.web.context.WebApplicationContext;
import org.testng.annotations.Test;

import java.util.regex.Matcher;


@SpringBootTest
@AutoConfigureMockMvc
public class NyTimesNewsControllerTest {
    @Autowired
    private ObjectMapper objectMapper;
    @Autowired
    private MockMvc mvc;

    @Test
    public void testFindAll() throws Exception {
        //List<News> news = repository.findAll();
        String expectedJsonResponse = "[{\"id\":1,\"title\":\"title 1\",\"details\":\"details 1\",\"tags\":\"tags 1\",\"reportedAt\":\"2000-01-01T12:00:00\"},{\"id\":2,\"title\":\"title 2\",\"details\":\"details 2\",\"tags\":\"tags 2\",\"reportedAt\":\"2000-01-01T12:00:00\"}]";
        mvc.perform(MockMvcRequestBuilders.get("/api/news/nyTimes/headlines"))
                .andDo(MockMvcResultHandlers.print())
                .andExpect(MockMvcResultMatchers.status().is2xxSuccessful())
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.content().string(Matchers.equalTo(expectedJsonResponse)));

//        mvc.perform(MockMvcRequestBuilders.get("/api/v1/news/1"))
//                //.with(testUser("reporter", "REPORTER")))
//                .andDo(MockMvcResultHandlers.print())
//                .andExpect(MockMvcResultMatchers.status().is2xxSuccessful())
//                .andExpect(MockMvcResultMatchers.jsonPath("$.id", Matchers.is(1)))
//                .andExpect(MockMvcResultMatchers.jsonPath("$.title", Matchers.is("title 1")))
//                .andExpect(MockMvcResultMatchers.jsonPath("$.details", Matchers.is("details 1")))
//                .andExpect(MockMvcResultMatchers.jsonPath("$.tags", Matchers.is("tags 1")))
//                .andExpect(MockMvcResultMatchers.jsonPath("$.reportedAt", Matchers.notNullValue()));
    }


}
